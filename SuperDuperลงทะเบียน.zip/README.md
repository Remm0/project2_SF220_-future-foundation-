# Svelte + Vite

This template should help get you started developing with Svelte in Vite.

The entry point for the app can be found in /src/App.svelte.


See svelte.dev to get started with Svelte!
